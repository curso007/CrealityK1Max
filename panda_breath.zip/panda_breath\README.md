# Panda Breath Integration � Creality K1 Max (Rooted)

Place all .cfg files inside:
/home/mks/klipper_config/includes/

Include them in printer.cfg as documented.
